# Improvement Checklist for CaduSallers

Based on the task requirements, we need to improve the existing CaduSallers bot.

## Current State Analysis (from index.js and store.json)

### What exists:
- Basic store with product listing (no category browsing)
- Product management (create, list, remove, change price)
- Stock management (add, remove, set)
- Cart system: creates private channel for each order, immediate Efí charge creation
- Efí Pix integration: charge creation, webhook for payment confirmation, QR code and copia e cola
- Administrative panel (/panel) with sections: store, carts, purchases, tools, metrics, settings
- Order tracking: stores orders with basic info
- Basic permissions (admin only for certain commands)
- Persistence via JSON file (store.json)
- Delivery system: "Entregue" button to finalize order, reduce stock, delete channel after countdown

## Missing or Needed Improvements

### 1. Category System
- [ ] Store should show categories and allow browsing by category
- [ ] Category management in panel (add, edit, remove categories)
- [ ] Products should belong to categories

### 2. Cart Improvements
- [ ] Support for multiple quantities per product
- [ ] Ability to add/remove products from cart
- [ ] Display subtotal, discount, total in cart
- [ ] Apply coupons to cart
- [ ] Cancel button should properly delete channel and clean up
- [ ] Stock validation to prevent overselling (reserve stock or check at purchase)

### 3. Coupon System
- [ ] Create coupons (percentage, fixed value)
- [ ] Set validity, usage limits, minimum value, product/category restrictions
- [ ] Validate coupons on server
- [ ] Apply coupons to cart

### 4. Order System
- [ ] Improve order ID format (e.g., CADU-000001)
- [ ] Store discount and coupon info in order
- [ ] Add order events/history
- [ ] Implement proper state machine: 
    CRIADO -> AGUARDANDO_PAGAMENTO -> PAGO -> PROCESSANDO_ENTREGA -> ENTREGUE -> FINALIZADO
    Also handle: CANCELADO, EXPIRADO, PAGAMENTO_FALHOU, ERRO_ENTREGA
- [ ] Never deliver without payment confirmation from gateway

### 5. Payment (PIX) Improvements
- [ ] Ensure webhook is idempotent (store processed webhook IDs)
- [ ] Improve error handling and confirmation
- [ ] Consider OAuth token refresh if needed

### 6. Webhook
- [ ] Make webhook idempotent by storing processed event IDs
- [ ] Prevent duplicate order processing, stock deduction, delivery, confirmation

### 7. Security
- [ ] Ensure no secrets in logs or code
- [ ] Validate all permissions server-side
- [ ] Use .env for secrets, .env.example for template

### 8. Persistence
- [ ] Ensure persistence of all necessary data (products, categories, stock, orders, payments, settings, coupons, cart info)
- [ ] Consider backup improvements (already has backups directory)

### 9. Delivery
- [ ] Improve "Entregue" button to:
    - Verify order and permissions
    - Update status to PROCESSANDO_ENTREGA then ENTREGUE
    - Register event
    - Update message
    - Initiate closure (countdown) and delete channel when appropriate
- [ ] Handle errors during delivery process
- [ ] Prevent dead channels

### 10. Tickets/Support System
- [ ] If not exists, implement basic ticket system (if architecture allows)
- [ ] Or improve existing if present

### 11. Metrics
- [ ] Expand metrics in panel (sales over time, popular products, etc.)

### 12. Administrative Tools
- [ ] Integrate more tools directly into panel (e.g., bulk operations)

### 13. Announcements
- [ ] Add announcement system (for storewide messages)

### 14. Logs
- [ ] Add log viewing in panel (or ensure logs are properly stored and accessible)

### 15. Configuration
- [ ] Allow editing of more settings from panel (e.g., store name, cart category, etc.)

### 16. Permissions
- [ ] Consider more granular permissions beyond just admin

### 17. Code Organization
- [ ] Consider splitting index.js into modules for maintainability (if necessary)
- [ ] Avoid duplication, keep functions focused

### 18. Testing
- [ ] After changes, test all flows: start bot, login, commands, /panel, store, category, product, stock, add to cart, remove from cart, apply coupon, cancel cart, checkout, payment, webhook, delivery, restart, persistence, etc.
- [ ] Create temporary test files and delete after testing

### 19. Documentation
- [ ] Update README.md with detailed instructions
- [ ] Ensure .env.example is complete

### 20. Clean Up
- [ ] Remove any temporary files created during development
- [ ] Ensure no useless files left

## Prioritization (based on impact and feasibility)

Given the time, we will focus on the most critical improvements that align with the task's emphasis on a professional store experience:

1. **Category System** - essential for store navigation
2. **Cart Improvements** (quantities, coupons, display) - core to purchasing
3. **Coupon System** - common in sales bots
4. **Order ID format and state machine** - for clarity and professionalism
5. **Webhook idempotency** - critical for payment reliability
6. **Delivery process improvements** - to match requirements
7. **Persistence and security** - already mostly there, but ensure robustness

We will implement these improvements in the index.js and possibly add a few new files if necessary (e.g., for coupon service).

We will avoid creating dozens of files; we will keep changes focused.

Let's now outline the specific changes we will make to the code.