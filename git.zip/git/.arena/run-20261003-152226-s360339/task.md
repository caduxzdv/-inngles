Você é o responsável pelo desenvolvimento do meu projeto CaduSallers.

IMPORTANTE: perdi a conversa anterior, então este prompt contém novamente todas as regras e objetivos do projeto.

============================================================
PROJETO
============================================================

Nome: CaduSallers

É um bot de vendas para Discord.

Ele é inspirado em funcionalidades e experiência de bots como zenSallers/Sallers, porém o CaduSallers deve ter IMPLEMENTAÇÃO PRÓPRIA.

Não copie código proprietário de terceiros.

Use referências apenas para entender:

- funcionalidades
- UX
- organização
- fluxo de compra
- aparência
- experiência do usuário

Repositório:

https://github.com/caduxzdv/-inngles

A pasta do projeto CaduSallers atualmente é:

CaduSallers-GITHUB

============================================================
REGRA MAIS IMPORTANTE DE TODAS
============================================================

NÃO APAGUE ARQUIVOS QUE JÁ SÃO USADOS PELO BOT.

NÃO saia apagando arquivos simplesmente porque parecem antigos.

ANTES de apagar QUALQUER arquivo:

1. leia o arquivo;
2. descubra se o bot usa esse arquivo;
3. procure referências/importações para ele;
4. descubra se ele contém dados necessários;
5. verifique se ele é utilizado durante a execução;
6. somente depois decida.

Se um arquivo já faz parte do funcionamento do CaduSallers:

MANTENHA-O.

Melhore o que existe.

Não substitua tudo sem necessidade.

Não destrua funcionalidades que já funcionam.

============================================================
UMA IMPLEMENTAÇÃO OFICIAL
============================================================

Quero UMA implementação oficial do CaduSallers.

Não quero:

CaduSallers_v2
CaduSallers_v3
CaduSallers_v4
index-new
index-fixed
index-final
index-final2
teste-final
bot-novo
bot-corrigido
copia
temp
old
backup espalhado

NÃO crie várias versões do mesmo código.

Se o código oficial atual estiver em:

index.js

melhore o index.js.

Se ele estiver dividido em módulos, melhore os módulos existentes.

NÃO faça uma segunda implementação só porque seria mais fácil.

============================================================
REGRA SOBRE NOVOS ARQUIVOS
============================================================

Você PODE criar arquivos novos quando eles forem REALMENTE necessários para melhorar o projeto.

Por exemplo:

src/services/payment.js
src/services/orders.js
src/utils/database.js

Mas NÃO crie arquivos simplesmente para duplicar código.

Antes de criar um arquivo:

pergunte a si mesmo:

"Esse arquivo é realmente necessário para o funcionamento/manutenção do projeto?"

Se sim, crie.

Se não, não crie.

============================================================
ARQUIVOS DE TESTE
============================================================

Você pode criar arquivos temporários para testar.

Exemplo:

test-pix.js
test-cart.js
debug-payment.js
test-order.js

MAS:

esses arquivos são temporários.

Depois que terminar todos os testes:

APAGUE os arquivos temporários.

Não deixe:

test.js
debug.js
temp.js
teste-final.js

abandonados no projeto.

No final:

git status

e verifique se não ficou lixo.

============================================================
ANTES DE ALTERAR
============================================================

Primeiro faça uma AUDITORIA COMPLETA.

Não altere imediatamente.

Leia:

- código principal
- package.json
- package-lock.json
- data
- configurações
- serviços
- comandos
- eventos
- arquivos relacionados ao bot

Descubra como o bot funciona atualmente.

Mapeie:

- inicialização
- comandos
- painel
- loja
- produtos
- categorias
- estoque
- carrinho
- pedidos
- pagamento
- entrega
- tickets
- cupons
- configurações
- persistência
- permissões

Depois disso, escolha a implementação ATUAL como base.

Não recrie o bot do zero sem necessidade.

============================================================
OBJETIVO PRINCIPAL
============================================================

Quero que você MELHORE o CaduSallers existente.

Não quero simplesmente outro bot.

Quero pegar o que já existe e transformar em um bot de vendas profissional.

Preserve tudo que já funciona.

Corrija o que está errado.

Complete o que está faltando.

Melhore o que está simples.

============================================================
INTERFACE / DESIGN
============================================================

Essa parte é MUITO importante.

O bot atualmente precisa ficar muito mais bonito e profissional.

Não quero uma interface genérica de:

"Produto:
Preço:
[Comprar]"

Quero uma experiência de loja Discord.

Use corretamente:

- Embeds
- Buttons
- Select Menus
- Modals
- emojis
- títulos
- descrições
- separação visual
- status
- preços
- estoque
- informações do pedido
- mensagens de sucesso
- mensagens de erro
- confirmações

A documentação do discord.js deve ser usada como referência oficial para os componentes.

Documentação:

https://discordjs.guide/

Buttons:

https://discordjs.guide/message-components/buttons.html

Select menus:

https://discordjs.guide/legacy/interactive-components/select-menus

Modals:

https://discordjs.guide/legacy/interactions/modals

Não use componentes de maneira exagerada.

A interface deve ficar bonita, limpa e fácil de entender.

============================================================
REFERÊNCIA DE LOJAS DISCORD
============================================================

Pesquise projetos públicos atuais de marketplace/Discord store.

Observe como eles organizam:

- vitrine
- categorias
- produtos
- carrinho
- checkout
- pedidos
- pagamento
- entrega
- painel administrativo

Exemplo de referência pública:

https://github.com/Marcelol090/discord-marketplace-bot

Use como REFERÊNCIA.

NÃO copie código.

Pesquise outras referências também.

Compare as ideias.

Pegue apenas conceitos de UX/arquitetura que façam sentido para o CaduSallers.

============================================================
VÍDEOS E REFERÊNCIAS QUE EU JÁ MANDEI
============================================================

Eu já tinha enviado vídeos mostrando o funcionamento do bot de referência zenSallers/Sallers.

A intenção daqueles vídeos era mostrar:

- aparência
- painel
- navegação
- loja
- categorias
- produtos
- carrinho
- checkout
- pagamento
- pedidos
- entrega
- experiência do cliente

Use os vídeos que estiverem realmente disponíveis no contexto/projeto.

IMPORTANTE:

Se você NÃO tiver acesso aos vídeos nesta sessão:

NÃO finja que assistiu.

Não invente detalhes.

Nesse caso use as informações disponíveis no projeto e pesquise referências públicas atuais.

============================================================
FUNCIONALIDADES DESEJADAS
============================================================

O CaduSallers deve caminhar para possuir:

/panel

Loja

Categorias

Produtos

Estoque

Carrinho

Checkout

PIX

Pedidos

Histórico

Entrega automática

Entrega manual

Cupons

Tickets

Suporte

Métricas

Ferramentas administrativas

Anúncios

Logs

Configurações

Permissões

Persistência

Recuperação após restart

============================================================
PAINEL
============================================================

O /panel deve ser o centro do sistema.

Quero uma interface administrativa organizada.

Exemplo:

🏪 Loja
📦 Produtos
🗂️ Categorias
📊 Estoque
🛒 Pedidos
💳 Pagamentos
🎟️ Cupons
🎫 Tickets
📈 Métricas
📢 Anúncios
⚙️ Configurações
🛡️ Segurança
📋 Logs

Não implemente algo falso só para preencher o painel.

Cada opção deve fazer alguma coisa real ou ficar claramente marcada como futura.

============================================================
LOJA
============================================================

Cliente deve conseguir:

1. abrir loja
2. ver categorias
3. escolher categoria
4. ver produtos
5. ver preço
6. ver estoque
7. abrir detalhes
8. adicionar ao carrinho
9. alterar quantidade
10. remover produto
11. aplicar cupom
12. ver subtotal
13. ver desconto
14. ver total
15. checkout
16. pagar
17. acompanhar pedido
18. receber produto

Tudo precisa ter feedback visual.

============================================================
CARRINHO
============================================================

Corrigir e melhorar completamente.

Deve permitir:

- adicionar produto
- remover produto
- quantidade
- estoque
- subtotal
- desconto
- total
- cancelar
- checkout

IMPORTANTE:

O botão:

❌ Cancelar

deve realmente cancelar o carrinho.

Se o carrinho usa canal privado:

o canal deve ser encerrado/removido corretamente.

Não deixar canais abandonados.

Antes de apagar um canal, trate erros.

============================================================
PEDIDOS
============================================================

Cada pedido deve possuir ID único.

Exemplo:

#CADU-000001

Guardar:

- ID
- usuário
- produtos
- quantidade
- preço
- desconto
- total
- pagamento
- status
- data
- entrega
- eventos

============================================================
ESTADOS
============================================================

Usar estados claros.

Exemplo:

CRIADO

↓

AGUARDANDO_PAGAMENTO

↓

PAGO

↓

PROCESSANDO_ENTREGA

↓

ENTREGUE

↓

FINALIZADO

Também tratar:

CANCELADO

EXPIRADO

PAGAMENTO_FALHOU

ERRO_ENTREGA

Nunca entregar um produto apenas porque alguém clicou em um botão.

============================================================
ESTOQUE
============================================================

Estoque precisa ser real.

Exemplo:

Estoque = 10

Compra = 1

Novo estoque = 9

Nunca permitir estoque negativo.

Proteja contra duas compras simultâneas.

Não permitir que dois usuários comprem a mesma unidade disponível.

============================================================
PAGAMENTO PIX
============================================================

NÃO criar PIX falso.

Quero integração real com Efí.

Documentação oficial:

https://dev.efipay.com.br/docs/api-pix/

Pesquisar a documentação atual antes de implementar.

Considerar:

- OAuth
- cobrança imediata
- txid
- valor
- chave Pix
- QR Code
- Pix Copia e Cola
- consulta
- webhook
- confirmação
- expiração
- idempotência
- tratamento de erros

Não considerar pagamento confirmado apenas porque o cliente clicou em:

"Já paguei"

O status precisa ser confirmado pelo gateway/API.

============================================================
WEBHOOK
============================================================

Webhook precisa ser idempotente.

Se o mesmo evento chegar duas vezes:

NÃO pode:

- duplicar pedido
- duplicar estoque
- entregar novamente
- gerar duas confirmações

Registrar/processar eventos de forma segura.

============================================================
SEGURANÇA
============================================================

NUNCA colocar secrets no código.

Não publicar:

DISCORD_TOKEN
EFI_CLIENT_ID
EFI_CLIENT_SECRET
certificados
private keys
senhas

Usar .env.

Criar/atualizar:

.env.example

somente com nomes das variáveis, sem secrets reais.

============================================================
PERSISTÊNCIA
============================================================

O bot não pode perder informações depois de reiniciar.

Preservar o sistema de persistência atual se ele já funciona.

Não trocar banco/JSON apenas por moda.

Melhorar o sistema existente.

Garantir persistência de:

- produtos
- categorias
- estoque
- pedidos
- pagamentos
- configurações
- cupons
- informações necessárias dos carrinhos

============================================================
ENTREGA
============================================================

Corrigir completamente a entrega.

Quando o pedido for pago:

PAGO

↓

PROCESSANDO_ENTREGA

↓

ENTREGUE

↓

FINALIZADO

O botão:

✅ Entregue

deve realmente:

1. verificar pedido;
2. verificar permissão;
3. atualizar status;
4. registrar evento;
5. atualizar mensagem;
6. iniciar encerramento;
7. apagar o canal quando apropriado.

Se houver countdown:

execute corretamente.

Se ocorrer erro:

registre e trate.

Não deixe canais mortos.

============================================================
TICKETS / SUPORTE
============================================================

Se já existir:

preserve.

Melhore.

Se não existir e a arquitetura comportar:

implemente de forma organizada.

Não crie um sistema gigante sem necessidade.

============================================================
CUPONS
============================================================

Preparar suporte para:

- percentual
- valor fixo
- validade
- limite de uso
- valor mínimo
- produto específico
- categoria específica

Sempre validar no servidor.

============================================================
PERMISSÕES
============================================================

Administradores precisam de permissões apropriadas.

Cliente não pode:

- alterar preço
- alterar estoque
- confirmar pagamento
- marcar próprio pedido como entregue
- acessar painel administrativo

Tudo precisa ser validado no servidor.

============================================================
CÓDIGO
============================================================

Não faça refatoração gigantesca sem necessidade.

Prefira:

MELHORAR O QUE EXISTE.

Se for necessário separar módulos:

faça de maneira gradual.

Evite criar dezenas de arquivos.

Evite código duplicado.

Evite funções gigantes quando puder organizar melhor.

============================================================
TESTES
============================================================

Depois das alterações, teste de verdade.

Teste:

1. iniciar bot
2. login
3. comandos
4. /panel
5. loja
6. categoria
7. produto
8. estoque
9. adicionar carrinho
10. remover carrinho
11. cancelar carrinho
12. fechamento do canal
13. checkout
14. pedido
15. pagamento
16. webhook
17. repetição do webhook
18. entrega
19. botão Entregue
20. encerramento do canal
21. restart
22. persistência
23. permissões
24. estoque simultâneo
25. tratamento de erros

Se precisar criar arquivos de teste:

CRIE.

USE.

TESTE.

DEPOIS APAGUE.

============================================================
NÃO DEIXAR LIXO
============================================================

Antes de finalizar:

procure por:

*_test*
test*
debug*
temp*
tmp*
old*
new*
fixed*
copy*
backup*

Mas ATENÇÃO:

NÃO apague automaticamente.

Verifique se cada arquivo é realmente temporário ou necessário.

Se foi criado durante este trabalho apenas para teste:

APAGUE.

Se já fazia parte do funcionamento:

MANTENHA.

============================================================
GIT
============================================================

Antes de grandes alterações:

verifique:

git status

Não destrua trabalho existente.

Depois:

git status

Revise todas as alterações.

Não deixe arquivos inúteis.

============================================================
DOCUMENTAÇÃO
============================================================

Atualize README.md para explicar:

- o que é o CaduSallers
- instalação
- npm install
- configuração .env
- comandos
- como iniciar
- configuração Pix
- estrutura
- testes
- segurança

Não colocar secrets.

============================================================
ARENA
============================================================

Use os 100 agentes para:

- analisar arquitetura
- encontrar bugs
- avaliar UX
- comparar soluções
- revisar segurança
- revisar fluxo de pagamentos
- revisar estoque
- revisar persistência
- revisar Discord interactions
- revisar experiência de compra

Mas não deixe cada agente criar sua própria versão do projeto.

Os agentes devem ANALISAR E SUGERIR.

A implementação final deve continuar sendo UMA só.

============================================================
RESULTADO FINAL
============================================================

No final quero:

CaduSallers funcionando.

Não quero:

20 versões.

Não quero:

arquivos duplicados.

Não quero:

testes abandonados.

Não quero:

código inventado.

Não quero:

pagamento falso.

Não quero:

UI genérica.

Quero:

UMA implementação oficial.

UMA arquitetura coerente.

UMA experiência de loja profissional.

Código existente preservado quando necessário.

Melhorias reais.

Testes reais.

Limpeza dos temporários.

============================================================
REGRA FINAL
============================================================

NÃO APAGUE O QUE VOCÊ NÃO ENTENDE.

Primeiro leia.

Depois entenda.

Depois teste.

Depois melhore.

Só remova algo se você comprovar que:

1. não é usado pelo bot;
2. não contém dados necessários;
3. não é dependência;
4. não é configuração necessária;
5. não é parte do funcionamento.

Se precisar criar algo para teste, tudo bem.

Mas quando terminar:

APAGUE O QUE FOI CRIADO APENAS PARA TESTE.

Trabalhe sempre na implementação oficial.

Não crie uma segunda versão do CaduSallers.

Agora use os 100 agentes para fazer a análise completa e, depois da análise, implemente as melhorias necessárias.
