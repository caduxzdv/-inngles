// ==UserScript==
// @name         CADUXZ Efekta Auto Study 8.5 — Auto Answer + Click + Verify
// @namespace    https://caduxz.local/
// @version      8.5.0
// @description  CADUXZ para Efekta: hub, navegação de lições, captura de dados do player, resolução de escolhas/ordenação/categorização/matching, tentativa controlada e avanço automático.
// @author       CADUXZ
// @match        https://learn.better.efekta.com/*
// @match        https://lesson-player.study.better.efekta.com/*
// @run-at       document-start
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_addStyle
// ==/UserScript==

(() => {
  'use strict';

  const VERSION = '8.5.0';
  const MAIN_HOST = 'learn.better.efekta.com';
  const PLAYER_HOST = 'lesson-player.study.better.efekta.com';
  const IS_MAIN = location.hostname === MAIN_HOST;
  const IS_PLAYER = location.hostname === PLAYER_HOST;
  const CHANNEL = 'CADUXZ_EFEKTA_8_5';

  const KEY = {
    enabled: 'caduxz85_enabled',
    telemetry: 'caduxz85_telemetry',
    bank: 'caduxz85_bank',
    done: 'caduxz85_done_lessons',
    attempts: 'caduxz85_attempts',
    currentLesson: 'caduxz85_current_lesson'
  };

  const CFG = {
    autoStart: true,
    scanMs: 650,
    settleMs: 700,
    verificationMs: 9000,
    maxNetwork: 140,
    maxPayload: 500000,
    maxTrialOptions: 10,
    maxPermutation: 7,
    maxCombos: 64,
    retryDelay: 450,
    assessmentStop: true
  };

  const state = {
    enabled: read(KEY.enabled, CFG.autoStart),
    phase: IS_MAIN ? 'PRONTO' : 'PLAYER',
    activityType: '-',
    task: '-',
    answer: '-',
    answerSource: '-',
    confidence: '-',
    lesson: '-',
    step: '-',
    completed: 0,
    scans: 0,
    actions: 0,
    successes: 0,
    failures: 0,
    errors: 0,
    message: 'CADUXZ 8.5 iniciado',
    startedAt: Date.now(),
    currentSignature: '',
    busy: false,
    lastAttemptAt: 0
  };

  let hub = null;
  let loopTimer = 0;
  let pageHookInstalled = false;
  let network = [];
  let seenNetwork = new Set();
  let lastSolveSignature = '';
  let retryTimer = 0;
  const attemptedOptions = new Map();
  let bc = null;
  try { bc = new BroadcastChannel(CHANNEL); } catch {}

  function read(k, fallback) {
    try { return GM_getValue(k, fallback); } catch { return fallback; }
  }
  function write(k, v) {
    try { GM_setValue(k, v); } catch {}
  }
  function clean(s) { return String(s ?? '').replace(/\s+/g, ' ').trim(); }
  function lower(s) { return clean(s).toLowerCase(); }
  function visible(el) {
    if (!el) return false;
    try {
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && cs.display !== 'none' && cs.visibility !== 'hidden' && cs.opacity !== '0';
    } catch { return false; }
  }
  function textOf(el) {
    if (!el) return '';
    return clean(el.getAttribute?.('aria-label') || el.getAttribute?.('title') || el.innerText || el.textContent || el.value || '');
  }
  function wait(ms) { return new Promise(r => setTimeout(r, ms)); }
  function nowTime() { return new Date().toLocaleTimeString('pt-BR', { hour12: false }); }

  function saveTelemetry(extra = {}) {
    Object.assign(state, extra);
    write(KEY.telemetry, {
      ...state,
      at: Date.now(),
      host: location.hostname,
      url: location.href
    });
    try { bc?.postMessage({ type: 'TELEMETRY', state }); } catch {}
    if (hub) renderHub();
  }

  function log(message, level = 'info') {
    state.message = message;
    if (hub) addLog(message, level);
    console.log(`[CADUXZ ${VERSION}] ${message}`);
  }

  function setPhase(phase, message = '') {
    state.phase = phase;
    if (message) state.message = message;
    saveTelemetry();
  }

  function addLog(message, level = 'info') {
    if (!hub?.log) return;
    const row = document.createElement('div');
    row.textContent = `[${nowTime()}] ${message}`;
    row.style.cssText = 'padding:3px 0;border-bottom:1px solid rgba(255,255,255,.05);font-size:11px;line-height:1.3;';
    row.style.color = level === 'error' ? '#ff6969' : level === 'warn' ? '#ffd166' : level === 'success' ? '#59ff9b' : '#c7ffd9';
    hub.log.appendChild(row);
    while (hub.log.childElementCount > 80) hub.log.firstElementChild.remove();
    hub.log.scrollTop = hub.log.scrollHeight;
  }

  function renderHub() {
    if (!hub) return;
    hub.toggle.textContent = state.enabled ? 'ON' : 'OFF';
    hub.toggle.style.background = state.enabled ? '#0d6b3b' : '#5b2020';
    hub.status.textContent = state.message;
    hub.phase.textContent = state.phase;
    hub.type.textContent = state.activityType;
    hub.lesson.textContent = state.lesson;
    hub.step.textContent = state.step;
    hub.answer.textContent = state.answer;
    hub.source.textContent = `${state.answerSource} · ${state.confidence}`;
    hub.stats.textContent = `ações ${state.actions} · acertos ${state.successes} · falhas ${state.failures} · scans ${state.scans} · dados ${network.length}`;
  }

  function createHub() {
    if (document.getElementById('caduxz85-hub')) document.getElementById('caduxz85-hub').remove();
    const root = document.createElement('div');
    root.id = 'caduxz85-hub';
    root.innerHTML = `
      <div class="caduxz85-head">
        <div><b>⚡ CADUXZ ${VERSION}</b><div class="caduxz85-mini">${IS_MAIN ? 'EFK MAIN' : 'LESSON PLAYER'}</div></div>
        <div class="caduxz85-actions"><button id="cx-toggle">${state.enabled ? 'ON' : 'OFF'}</button><button id="cx-collapse">—</button></div>
      </div>
      <div id="cx-body">
        <div class="cx-grid">
          <div><small>FASE</small><strong id="cx-phase">${state.phase}</strong></div>
          <div><small>TIPO</small><strong id="cx-type">-</strong></div>
          <div><small>LIÇÃO</small><strong id="cx-lesson">-</strong></div>
          <div><small>ETAPA</small><strong id="cx-step">-</strong></div>
        </div>
        <div class="cx-line"><span>ATUAL</span><div id="cx-status">${state.message}</div></div>
        <div class="cx-line"><span>RESPOSTA</span><div id="cx-answer">-</div></div>
        <div class="cx-line"><span>FONTE</span><div id="cx-source">-</div></div>
        <div class="cx-line"><span>STATUS</span><div id="cx-stats">-</div></div>
        <div class="cx-buttons"><button id="cx-next">NEXT / CONTINUAR</button><button id="cx-stop">PARAR</button><button id="cx-clear">LIMPAR BANCO</button></div>
        <div id="cx-log"></div>
      </div>`;
    root.style.cssText = `position:fixed;right:12px;top:12px;width:360px;z-index:2147483647;font-family:ui-monospace,SFMono-Regular,Consolas,monospace;color:#fff;background:rgba(9,12,14,.97);border:1px solid #2ae88a;border-radius:12px;box-shadow:0 12px 45px rgba(0,0,0,.45);font-size:12px;backdrop-filter:blur(7px);`;
    root.querySelector('#cx-body').style.cssText = 'padding:10px;';
    const head = root.querySelector('.caduxz85-head');
    head.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:10px;border-bottom:1px solid #193f30;cursor:move;';
    root.querySelector('.caduxz85-mini').style.cssText = 'font-size:10px;color:#8bb9a2;margin-top:2px;';
    root.querySelector('.caduxz85-actions').style.cssText = 'display:flex;gap:5px;';
    root.querySelectorAll('button').forEach(b => b.style.cssText = 'border:1px solid #2ae88a;background:#0f2b21;color:#dfffee;border-radius:7px;padding:5px 8px;font:inherit;cursor:pointer;');
    root.querySelector('#cx-stop').style.background = '#3e1a1a';
    root.querySelector('#cx-clear').style.background = '#272c2d';
    root.querySelector('#cx-next').style.background = '#163a28';
    root.querySelector('.cx-grid').style.cssText = 'display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:9px;';
    root.querySelectorAll('.cx-grid > div').forEach(d => d.style.cssText = 'background:#11181a;border:1px solid #1c3028;border-radius:7px;padding:6px;min-width:0;');
    root.querySelectorAll('.cx-grid small').forEach(d => d.style.cssText = 'display:block;color:#719986;font-size:9px;');
    root.querySelectorAll('.cx-grid strong').forEach(d => d.style.cssText = 'display:block;color:#d5ffe7;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:2px;');
    root.querySelectorAll('.cx-line').forEach(d => d.style.cssText = 'margin:6px 0;padding:6px 7px;background:#0d1315;border-radius:7px;border:1px solid #18241f;');
    root.querySelectorAll('.cx-line > span').forEach(d => d.style.cssText = 'display:block;color:#6f9a83;font-size:9px;margin-bottom:3px;');
    root.querySelector('#cx-log').style.cssText = 'max-height:170px;overflow:auto;margin-top:8px;padding-top:5px;border-top:1px solid #193f30;';
    root.querySelector('.cx-buttons').style.cssText = 'display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;margin-top:8px;';
    document.documentElement.appendChild(root);
    hub = {
      root,
      toggle: root.querySelector('#cx-toggle'),
      phase: root.querySelector('#cx-phase'),
      type: root.querySelector('#cx-type'),
      lesson: root.querySelector('#cx-lesson'),
      step: root.querySelector('#cx-step'),
      status: root.querySelector('#cx-status'),
      answer: root.querySelector('#cx-answer'),
      source: root.querySelector('#cx-source'),
      stats: root.querySelector('#cx-stats'),
      log: root.querySelector('#cx-log')
    };
    root.querySelector('#cx-toggle').onclick = () => { state.enabled = !state.enabled; write(KEY.enabled, state.enabled); setPhase(state.enabled ? 'ATIVO' : 'PAUSADO', state.enabled ? 'Automação ligada' : 'Automação pausada'); };
    root.querySelector('#cx-stop').onclick = () => { state.enabled = false; write(KEY.enabled, false); saveTelemetry({ phase:'PAUSADO', message:'Pausado pelo usuário' }); };
    root.querySelector('#cx-clear').onclick = () => { if (confirm('Limpar banco de respostas e tentativas?')) { write(KEY.bank, {}); write(KEY.attempts, {}); addLog('Banco limpo', 'success'); } };
    root.querySelector('#cx-collapse').onclick = () => {
      const body = root.querySelector('#cx-body');
      body.hidden = !body.hidden;
      root.querySelector('#cx-collapse').textContent = body.hidden ? '+' : '—';
    };
    root.querySelector('#cx-next').onclick = () => continueOrNext(true);
    makeDraggable(root, head);
    renderHub();
    addLog(`Hub ${VERSION} inicializado`, 'success');
  }

  function makeDraggable(root, handle) {
    let dragging = false, sx = 0, sy = 0, ox = 0, oy = 0;
    handle.addEventListener('pointerdown', e => { dragging = true; sx = e.clientX; sy = e.clientY; const r = root.getBoundingClientRect(); ox = r.left; oy = r.top; handle.setPointerCapture?.(e.pointerId); });
    handle.addEventListener('pointermove', e => { if (!dragging) return; root.style.left = `${Math.max(0, ox + e.clientX - sx)}px`; root.style.top = `${Math.max(0, oy + e.clientY - sy)}px`; root.style.right = 'auto'; });
    handle.addEventListener('pointerup', () => { dragging = false; });
  }

  function allRoots() {
    const out = [document];
    const q = [document];
    const seen = new Set();
    while (q.length) {
      const root = q.shift();
      if (seen.has(root)) continue;
      seen.add(root);
      for (const el of Array.from(root.querySelectorAll?.('*') || [])) {
        if (el.shadowRoot && !out.includes(el.shadowRoot)) { out.push(el.shadowRoot); q.push(el.shadowRoot); }
      }
    }
    return out;
  }
  function qsa(selector) {
    const arr = [];
    for (const root of allRoots()) {
      try { arr.push(...root.querySelectorAll(selector)); } catch {}
    }
    return [...new Set(arr)];
  }

  function installPageHook() {
    if (!IS_PLAYER || pageHookInstalled) return;
    pageHookInstalled = true;
    const push = (body, source, url) => {
      try { window.dispatchEvent(new CustomEvent('CADUXZ85_NET', { detail:{ body:String(body||''), source, url:String(url||'') } })); } catch {}
    };
    window.addEventListener('CADUXZ85_NET', e => ingestPayload(e.detail?.body, e.detail?.source, e.detail?.url));
    const code = `(() => {
      if (window.__CADUXZ85_HOOK__) return; window.__CADUXZ85_HOOK__ = true;
      const emit = ${push.toString()};
      const oldFetch = window.fetch;
      if (oldFetch) window.fetch = async function(...args){
        const r = await oldFetch.apply(this,args);
        try { const c=r.clone(); const ct=c.headers.get('content-type')||''; if(/json|text|javascript|graphql/i.test(ct)) c.text().then(t=>emit(t,'page-fetch',args[0]?.url||args[0]||'')).catch(()=>{}); } catch{}
        return r;
      };
      const oo=XMLHttpRequest.prototype.open, os=XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open=function(m,u,...r){ this.__cxurl=String(u||''); return oo.call(this,m,u,...r); };
      XMLHttpRequest.prototype.send=function(...a){ this.addEventListener('load',()=>{ try{ const ct=this.getResponseHeader('content-type')||''; const t=typeof this.responseText==='string'?this.responseText:''; if(/json|text|javascript|graphql/i.test(ct)) emit(t,'page-xhr',this.__cxurl||''); }catch{} }); return os.apply(this,a); };
    })();`;
    try { const s=document.createElement('script'); s.textContent=code; (document.documentElement||document.head||document.body).appendChild(s); s.remove(); } catch(e) { log('Hook de página falhou; usando captura isolada', 'warn'); }
    try {
      const of=window.fetch;
      if (of) window.fetch = async function(...args){
        const r=await of.apply(this,args);
        try{ const c=r.clone(); const ct=c.headers.get('content-type')||''; if(/json|text|javascript|graphql/i.test(ct)) c.text().then(t=>ingestPayload(t,'sandbox-fetch',args[0]?.url||args[0]||'')).catch(()=>{}); }catch{}
        return r;
      };
      const oo=XMLHttpRequest.prototype.open, os=XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open=function(m,u,...r){ this.__cxurl=String(u||''); return oo.call(this,m,u,...r); };
      XMLHttpRequest.prototype.send=function(...a){ this.addEventListener('load',()=>{ try{ const ct=this.getResponseHeader('content-type')||''; const t=typeof this.responseText==='string'?this.responseText:''; if(/json|text|javascript|graphql/i.test(ct)) ingestPayload(t,'sandbox-xhr',this.__cxurl||''); }catch{} }); return os.apply(this,a); };
    } catch {}
  }

  function ingestPayload(raw, source='unknown', url='') {
    if (!raw || String(raw).length < 2 || String(raw).length > CFG.maxPayload) return;
    const key = source+'|'+url+'|'+String(raw).slice(0,400);
    if (seenNetwork.has(key)) return;
    seenNetwork.add(key);
    let value = null;
    try { value = JSON.parse(raw); } catch {
      const trimmed=String(raw).trim();
      if (!/^[\[{]/.test(trimmed)) return;
      try { value=JSON.parse(trimmed); } catch { return; }
    }
    if (!value) return;
    network.push({value, source, url, at:Date.now()});
    while (network.length > CFG.maxNetwork) network.shift();
    if (IS_PLAYER) {
      saveTelemetry();
      try { window.parent?.postMessage({channel:CHANNEL,type:'NETWORK',payload:{value,source,url}}, '*'); } catch {}
    }
  }

  window.addEventListener('message', e => {
    const m=e.data;
    if (!m || m.channel !== CHANNEL) return;
    if (m.type === 'NETWORK_FROM_PLAYER' && IS_MAIN) ingestPayload(JSON.stringify(m.payload?.value||{}), 'player-forward', m.payload?.url||'');
    if (m.type === 'TELEMETRY' && IS_MAIN && m.state) Object.assign(state, m.state), renderHub();
    if (m.type === 'LESSON_DONE' && IS_MAIN) {
      const cur=read(KEY.currentLesson,''); if(cur) saveDone(cur);
      setPhase('LIÇÃO CONCLUÍDA','Voltando para escolher a próxima não concluída');
      setTimeout(()=>{ if(state.enabled) location.href='https://learn.better.efekta.com/gap/ui/self-study'; },900);
    }
    if (m.type === 'PING') e.source?.postMessage({channel:CHANNEL,type:'PONG',host:location.host}, '*');
  });

  function bridgeNetworkToParent() {
    if (!IS_PLAYER) return;
    window.addEventListener('message', e => {
      if (e.data?.channel !== CHANNEL) return;
    });
    // mirror new entries to parent
    let mirrored = 0;
    setInterval(() => {
      while (mirrored < network.length) {
        const item = network[mirrored++];
        try { window.parent?.postMessage({channel:CHANNEL,type:'NETWORK_FROM_PLAYER',payload:item}, '*'); } catch {}
      }
    }, 500);
  }

  function assessmentBlocked() {
    if (!CFG.assessmentStop) return false;
    const t = lower(document.body?.innerText || '');
    const strong = /(certification|certification test|formal exam|official exam|toeic\s+test|toefl\s+test|avalia[cç][aã]o oficial|prova final|exame final)/i;
    return strong.test(t);
  }

  function getTaskText() {
    const candidates = qsa('h1,h2,h3,h4,[role="heading"],[data-testid*="instruction" i],[class*="instruction" i],[class*="prompt" i],[class*="question" i],p,span,div');
    const list=[];
    for (const el of candidates) {
      if (!visible(el)) continue;
      const tx=clean(el.innerText||el.textContent||'');
      if (tx.length<8 || tx.length>500) continue;
      if (/(select|choose|question|task|put|match|sort|drag|drop|fill|complete|categor|order|which|what|qual|selecione|escolha|arraste|ordene|relacione)/i.test(tx)) list.push(tx);
    }
    return [...new Set(list)].sort((a,b)=>a.length-b.length)[0] || clean(document.body?.innerText||'').slice(0,500) || 'Atividade';
  }

  function getVisibleOptions() {
    const selectors = [
      'button:not([disabled])','[role="option"]','[role="radio"]','[role="checkbox"]','label','[data-option]','[data-answer]','[draggable="true"]','[data-rbd-draggable-id]','[aria-roledescription*="sortable" i]'
    ];
    const seen=new Set(), out=[];
    for (const sel of selectors) {
      for (const el of qsa(sel)) {
        if (!visible(el) || seen.has(el)) continue;
        const tx=clean(el.getAttribute('data-option')||el.getAttribute('data-answer')||el.getAttribute('aria-label')||el.innerText||el.textContent||el.value||'');
        if (!tx || tx.length>260) continue;
        if (/^(next|continue|check|confirm|submit|skip|help|need some help|próximo|continuar|verificar|confirmar|pular)$/i.test(tx)) continue;
        seen.add(el); out.push({el,text:tx,idx:out.length});
      }
    }
    return out;
  }

  function activityType(task, options) {
    const t=lower(task+' '+(document.body?.innerText||''));
    if (/sort the items|categor|group (the|these)|words for .* years old/.test(t)) return 'CATEGORIZATION';
    if (/put .* in .*order|youngest.*oldest|oldest.*youngest|sort .* order|ordering|sequence/.test(t)) return 'SEQUENCING';
    if (/match|connect|combine|relat|pair/.test(t)) return 'MATCHING';
    if (/fill in|fill the gap|blank|complete the sentence|missing word/.test(t)) return 'GAP_FILL';
    if (/speaking|microphone|speak/.test(t)) return 'SPEAKING';
    if (/writing|write|essay/.test(t)) return 'WRITING';
    if (options.length) return qsa('input[type="checkbox"], [role="checkbox"]').some(visible) ? 'MULTI_CHOICE' : 'CHOICE';
    if (/listening|listen|audio/.test(t)) return 'LISTENING';
    if (/video|watch/.test(t)) return 'VIDEO';
    return 'UNKNOWN';
  }

  function optionSignature(options) { return options.map(o=>lower(o.text)).join('|').slice(0,1200); }
  function activitySignature(type, task, options) { return `${location.pathname}|${type}|${clean(task)}|${optionSignature(options)}`.slice(0,3500); }

  function normalizeKey(type, task, options) {
    return btoa(unescape(encodeURIComponent(`${type}|${clean(task).toLowerCase()}|${optionSignature(options)}`))).slice(0,280);
  }

  function readBank() { return read(KEY.bank, {}) || {}; }
  function saveBank(b) { write(KEY.bank,b); }
  function rememberAnswer(type,task,options,answer,source,confidence) {
    const b=readBank(); b[normalizeKey(type,task,options)]={answer,source,confidence,at:Date.now()}; saveBank(b);
  }
  function bankAnswer(type,task,options) { return readBank()[normalizeKey(type,task,options)] || null; }

  function valuesFromObject(node, depth=0, hits=[]) {
    if (node==null || depth>8 || hits.length>100) return hits;
    if (Array.isArray(node)) { for (const x of node) valuesFromObject(x,depth+1,hits); return hits; }
    if (typeof node!=='object') return hits;
    for (const [k,v] of Object.entries(node)) {
      const lk=k.toLowerCase();
      if (/(correctanswer|correctanswers|correctoption|correctoptions|correctoptionid|correctoptionids|correctorder|expectedorder|expectedanswer|expectedanswers|correctsequence|answerkey|solution|solutions|rightanswer)/i.test(lk)) hits.push({key:k,value:v});
      if (v && typeof v==='object') valuesFromObject(v,depth+1,hits);
    }
    return hits;
  }

  function relatedPayloads(task) {
    const toks=lower(task).split(/[^a-z0-9à-ÿ]+/i).filter(x=>x.length>=4).slice(0,10);
    return [...network].reverse().filter(n=>{
      let s=''; try{s=lower(JSON.stringify(n.value)).slice(0,60000);}catch{return false;}
      const hits=toks.filter(t=>s.includes(t)).length;
      return toks.length ? hits>=Math.min(2,toks.length) : true;
    });
  }

  function extractAnswerFromData(type,task,options) {
    // 1) answer bank learned from previous successful tries
    const cached=bankAnswer(type,task,options); if (cached) return cached;
    // 2) explicit answer fields from loaded JSON/network
    for (const pack of relatedPayloads(task)) {
      for (const hit of valuesFromObject(pack.value)) {
        const normalized=normalizeAnswerValue(hit.value,type,options);
        if (normalized != null) return {answer:normalized,source:`DADOS:${pack.source}/${hit.key}`,confidence:96};
      }
    }
    // 3) state objects with per-option correctness flags
    for (const pack of relatedPayloads(task)) {
      const found=findMarkedCorrect(pack.value,options,0);
      if (found) return {answer:found,source:`DADOS:${pack.source}/marked`,confidence:94};
    }
    return null;
  }

  function normalizeAnswerValue(value,type,options) {
    if (value==null) return null;
    if (typeof value==='string' || typeof value==='number') return String(value);
    if (Array.isArray(value)) {
      const arr=value.map(v=>normalizeAnswerValue(v,type,options)).flat().filter(Boolean);
      return arr.length?arr:null;
    }
    if (typeof value==='object') {
      const direct=['answer','answers','correctAnswer','correctAnswers','solution','solutions','expected','expectedAnswer','expectedAnswers','rightAnswer','order','sequence','correctOrder','expectedOrder'];
      for (const k of direct) if (Object.prototype.hasOwnProperty.call(value,k)) { const x=normalizeAnswerValue(value[k],type,options); if(x!=null)return x; }
      const ids=['answerId','answerIds','correctOptionId','correctOptionIds','correctOption'];
      for (const k of ids) if (Object.prototype.hasOwnProperty.call(value,k)) {
        const x=value[k]; const xs=Array.isArray(x)?x.map(String):[String(x)];
        const mapped=options.filter(o=>xs.includes(String(o.el.dataset?.id||o.el.value||o.el.getAttribute('data-id')||o.el.getAttribute('data-option-id')||''))).map(o=>o.text);
        if(mapped.length) return mapped.length===1?mapped[0]:mapped;
      }
    }
    return null;
  }

  function findMarkedCorrect(node,options,depth=0) {
    if (!node||depth>9) return null;
    if (Array.isArray(node)) { for(const x of node){const f=findMarkedCorrect(x,options,depth+1);if(f)return f;} return null; }
    if (typeof node!=='object') return null;
    const objvals=Object.values(node);
    for (const v of objvals) {
      if (!v||typeof v!=='object') continue;
      if (v.correct===true || v.isCorrect===true || v.is_answer===true || v.isAnswer===true) {
        const txt=clean(v.text||v.label||v.value||v.answer||v.title||v.name||'');
        if(txt) return txt;
        const id=String(v.id||v.optionId||v.answerId||'');
        const mapped=options.find(o=>String(o.el.dataset?.id||o.el.getAttribute('data-id')||o.el.getAttribute('data-option-id')||'')===id);
        if(mapped)return mapped.text;
      }
    }
    for(const v of objvals){const f=findMarkedCorrect(v,options,depth+1);if(f)return f;}
    return null;
  }

  async function revealQuestionChoices(task) {
    // Some Efekta activities expose answer choices only after expanding the task/question.
    const before=optionSignature(getVisibleOptions());
    const candidates=qsa('button,[role="button"],[aria-expanded="false"],h1,h2,h3,h4,summary,div,span').filter(visible);
    const needles=[clean(task).slice(0,100),'question','task','step'];
    for(const n of needles){
      if(!n||n.length<5)continue;
      const el=candidates.find(x=>textOf(x).toLowerCase().includes(n.toLowerCase()) && !/next|continue|submit|check|confirm/i.test(textOf(x)));
      if(el){ safeClick(el,'REVELAR'); await wait(250); const after=optionSignature(getVisibleOptions()); if(after!==before)return true; }
    }
    const collapsed=qsa('[aria-expanded="false"],details:not([open])').filter(visible);
    for(const el of collapsed.slice(0,5)){ safeClick(el,'ABRIR'); await wait(180); }
    return optionSignature(getVisibleOptions())!==before;
  }

  function findClickable(el) {
    if(!el)return null;
    if(el.matches('button,a,label,[role="button"],[role="option"],[role="radio"],[role="checkbox"],[tabindex]')) return el;
    return el.closest?.('button,a,label,[role="button"],[role="option"],[role="radio"],[role="checkbox"],[tabindex]') || el;
  }

  function safeClick(el,action='CLICK') {
    if(!el || !state.enabled) return false;
    const target=findClickable(el)||el;
    try{ target.scrollIntoView({block:'center',inline:'center'});}catch{}
    try{ target.focus({preventScroll:true}); }catch{}
    try{
      const r=target.getBoundingClientRect();
      const opts={bubbles:true,cancelable:true,composed:true,view:window,clientX:r.left+r.width/2,clientY:r.top+r.height/2};
      target.dispatchEvent(new PointerEvent('pointerdown',{...opts,pointerId:1,pointerType:'mouse',isPrimary:true}));
      target.dispatchEvent(new MouseEvent('mousedown',opts));
      target.dispatchEvent(new PointerEvent('pointerup',{...opts,pointerId:1,pointerType:'mouse',isPrimary:true}));
      target.dispatchEvent(new MouseEvent('mouseup',opts));
    }catch{}
    try{ target.click(); }catch{}
    try{ target.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true,cancelable:true,composed:true})); target.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',bubbles:true,composed:true})); }catch{}
    state.actions++; state.message=`${action}: ${textOf(target).slice(0,80)}`; saveTelemetry();
    return true;
  }

  function nextButton() {
    const candidates=qsa('button,a,[role="button"],[role="link"],[tabindex]') .filter(visible);
    const regex=/^(next|continue|proceed|continuar|próximo|avançar|avancar|seguir|concluir|done|finish|go on|start|começar)$/i;
    return candidates.find(el=>regex.test(clean(el.getAttribute('aria-label')||el.getAttribute('title')||el.innerText||el.textContent||'')))
      || candidates.find(el=>/(next|continue|continuar|pr[oó]ximo|avançar|seguir|finish|concluir)/i.test(textOf(el)) && !/help|skip/i.test(textOf(el)));
  }

  function checkButton() {
    const c=qsa('button,a,[role="button"],[tabindex]').filter(visible);
    return c.find(el=>/^(check|confirm|confirmar|verificar|submit|enviar|done|concluir|verify)$/i.test(textOf(el)))
      || c.find(el=>/\b(check|confirm|verificar|submit|verify)\b/i.test(textOf(el)));
  }

  function retryButton() {
    return qsa('button,a,[role="button"]').filter(visible).find(el=>/try again|retry|tente novamente|refazer|retry activity/i.test(textOf(el)));
  }

  function resultState() {
    const body=clean(document.body?.innerText||'');
    // Avoid generic "correct option" text from the question itself.
    if (/Activity:\s*Passed|Atividade:\s*Passed|atividade\s+conclu[ií]da|lesson complete|correct answers:\s*\d+\s*\/\s*\d+/i.test(body)) return 'passed';
    if (/Activity:\s*(Failed|Not Passed)|incorrect answer|incorrect order|try again|tente novamente|errado|incorreto/i.test(body)) return 'failed';
    if (qsa('[data-result="correct"],.correct,.success,.passed,[aria-label*="correct" i]').some(visible)) return 'passed';
    if (qsa('[data-result="incorrect"],.incorrect,.failed,.error,[aria-label*="incorrect" i]').some(visible)) return 'failed';
    return 'pending';
  }

  async function verifyAfterCheck(beforeSig) {
    const t0=Date.now();
    while(Date.now()-t0<CFG.verificationMs){
      const r=resultState(); if(r!=='pending')return r;
      const sig=activitySignature(activityType(getTaskText(),getVisibleOptions()),getTaskText(),getVisibleOptions());
      if(sig!==beforeSig && (nextButton() || retryButton())) return nextButton() ? 'completed':'failed';
      await wait(350);
    }
    return nextButton() ? 'completed':'pending';
  }

  function clickByText(value) {
    const expected=lower(value);
    const candidates=getVisibleOptions();
    const exact=candidates.find(o=>lower(o.text)===expected);
    if(exact)return safeClick(exact.el,'RESPOSTA');
    const partial=candidates.find(o=>lower(o.text).includes(expected)||expected.includes(lower(o.text)));
    return partial ? safeClick(partial.el,'RESPOSTA') : false;
  }

  function setInput(el,value) {
    if(!el)return false;
    try{
      el.focus();
      if(el.isContentEditable) el.textContent=String(value);
      else if(el.tagName.toLowerCase()==='select'){
        const opt=[...el.options].find(o=>lower(o.textContent)===lower(value)||lower(o.value)===lower(value)||lower(o.textContent).includes(lower(value)));
        if(!opt)return false; el.value=opt.value;
      }else{
        const proto=el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
        const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set; setter?setter.call(el,String(value)):el.value=String(value);
      }
      el.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:String(value)}));
      el.dispatchEvent(new Event('change',{bubbles:true,composed:true}));
      return true;
    }catch{return false;}
  }

  function sortableItems() {
    const sels=['[aria-roledescription*="sortable" i]','[role="listitem"][tabindex]','[draggable="true"]','[data-rbd-draggable-id]','[data-sortable-id]'];
    const out=[]; const seen=new Set();
    for(const s of sels)for(const el of qsa(s).filter(visible)){
      if(seen.has(el))continue; seen.add(el); const tx=clean(el.innerText||el.textContent||el.getAttribute('aria-label')||''); if(tx)out.push({el,text:tx});
    }
    return out;
  }

  function dispatchKey(el,key){ try{el.focus();el.dispatchEvent(new KeyboardEvent('keydown',{key,code:key,bubbles:true,cancelable:true,composed:true}));el.dispatchEvent(new KeyboardEvent('keyup',{key,code:key,bubbles:true,composed:true}));return true;}catch{return false;} }

  async function keyboardMove(item,targetIndex){
    const items=sortableItems(); const ix=items.findIndex(x=>x.el===item.el||lower(x.text)===lower(item.text)); if(ix<0)return false;
    try{item.el.focus(); if(!item.el.hasAttribute('tabindex'))item.el.setAttribute('tabindex','0');}catch{}
    dispatchKey(item.el,'Enter'); await wait(80);
    let cur=ix;
    while(cur>targetIndex){dispatchKey(item.el,'ArrowUp');await wait(55);cur--;}
    while(cur<targetIndex){dispatchKey(item.el,'ArrowDown');await wait(55);cur++;}
    dispatchKey(item.el,'Enter'); await wait(100); return true;
  }

  function dragHTML5(source,target){
    try{
      const dt=new DataTransfer();
      source.dispatchEvent(new DragEvent('dragstart',{bubbles:true,cancelable:true,dataTransfer:dt}));
      target.dispatchEvent(new DragEvent('dragenter',{bubbles:true,cancelable:true,dataTransfer:dt}));
      target.dispatchEvent(new DragEvent('dragover',{bubbles:true,cancelable:true,dataTransfer:dt}));
      target.dispatchEvent(new DropEvent?new Event('drop',{bubbles:true,cancelable:true}):new DragEvent('drop',{bubbles:true,cancelable:true,dataTransfer:dt}));
      source.dispatchEvent(new DragEvent('dragend',{bubbles:true,cancelable:true,dataTransfer:dt}));
      return true;
    }catch{return false;}
  }

  async function solveSequence(task,options,answer) {
    let order = Array.isArray(answer)?answer:answer?.order;
    if(!order){
      const t=lower(task);
      if(/youngest.*oldest/.test(t)){
        const rank = txt => { const x=lower(txt); for(const [k,v] of [['newborn',1],['infant',2],['toddler',3],['teen',4],['teenager',4],['adolescent',4],['adult',5],['middle-aged',6],['middle aged',6],['pensioner',7],['senior',7],['centenarian',8]]) if(x.includes(k))return v; return 999;};
        order=[...options].sort((a,b)=>rank(a.text)-rank(b.text)).map(o=>o.text);
      }else if(/oldest.*youngest/.test(t)){
        const rank = txt => { const x=lower(txt); for(const [k,v] of [['newborn',1],['infant',2],['toddler',3],['teen',4],['teenager',4],['adolescent',4],['adult',5],['middle-aged',6],['middle aged',6],['pensioner',7],['senior',7],['centenarian',8]]) if(x.includes(k))return v; return 999;};
        order=[...options].sort((a,b)=>rank(b.text)-rank(a.text)).map(o=>o.text);
      }else if(/alphabet/i.test(t)) order=[...options].sort((a,b)=>a.text.localeCompare(b.text)).map(o=>o.text);
      else return false;
    }
    // Keyboard sortable is usually the least fragile route.
    for(let i=0;i<order.length;i++){
      const item=sortableItems().find(x=>lower(x.text)===lower(String(order[i]))||lower(x.text).includes(lower(String(order[i])))||lower(String(order[i])).includes(lower(x.text)));
      if(item) await keyboardMove(item,i);
    }
    return true;
  }

  function answerCombinations(options,max=CFG.maxCombos){
    const out=[];
    const n=options.length;
    const limit=Math.min(n,8);
    for(let r=1;r<=limit && out.length<max;r++){
      const pick=[];
      const rec=(start)=>{
        if(out.length>=max)return;
        if(pick.length===r){out.push([...pick]);return;}
        for(let i=start;i<n;i++){pick.push(options[i]);rec(i+1);pick.pop();if(out.length>=max)break;}
      };
      rec(0);
    }
    return out;
  }

  async function applyAnswer(type,task,options,answer){
    if(type==='CHOICE' || type==='MULTI_CHOICE'){
      const vals=Array.isArray(answer)?answer:[answer]; let ok=false;
      for(const v of vals) ok=clickByText(typeof v==='string'?v:(v.text||v.value||v.label||''))||ok;
      return ok;
    }
    if(type==='GAP_FILL' || type==='WRITING'){
      const fields=qsa('input:not([type="hidden"]),textarea,[contenteditable="true"],select').filter(visible);
      if(Array.isArray(answer)){ let ok=false; fields.forEach((f,i)=>{if(answer[i]!=null)ok=setInput(f,answer[i])||ok;});return ok; }
      return fields.length?setInput(fields[0],typeof answer==='string'?answer:(answer.text||answer.value||answer.answer||'')):clickByText(String(answer));
    }
    if(type==='SEQUENCING') return solveSequence(task,options,answer);
    if(type==='MATCHING' || type==='CATEGORIZATION'){
      if(answer && typeof answer==='object' && !Array.isArray(answer)){
        let ok=false;
        for(const [left,right] of Object.entries(answer)){
          const a=getVisibleOptions().find(o=>lower(o.text).includes(lower(left))||lower(left).includes(lower(o.text)));
          const b=getVisibleOptions().find(o=>lower(o.text).includes(lower(String(right)))||lower(String(right)).includes(lower(o.text)));
          if(a&&b){ok=dragHTML5(a.el,b.el)||ok;await wait(120);}
        }
        return ok;
      }
    }
    return answer?clickByText(String(answer)):false;
  }

  async function tryChoiceTrial(task,options,type){
    if(!options.length)return false;
    if(type==='CHOICE'){
      const sig=activitySignature(type,task,options);
      const tried=attemptedOptions.get(sig)||new Set();
      for(const o of options.slice(0,CFG.maxTrialOptions)){
        if(!state.enabled)return false;
        if(tried.has(lower(o.text))) continue;
        tried.add(lower(o.text)); attemptedOptions.set(sig,tried);
        const current=resultState();
        if(current==='failed'){ const r=retryButton(); if(r){safeClick(r,'RETRY'); await wait(CFG.retryDelay);} }
        if(!safeClick(o.el,'TESTE')) continue;
        await wait(220);
        const c=checkButton(); if(c)safeClick(c,'CHECK');
        const r=await verifyAfterCheck(sig);
        if(r==='passed'||r==='completed'){
          rememberAnswer(type,task,options,o.text,'TENTATIVA-CONTROLADA',100);
          return true;
        }
      }
      return false;
    }
    return false;
  }

  async function processPlayer() {
    if(!IS_PLAYER || !state.enabled || state.busy) return;
    if(assessmentBlocked()){ state.enabled=false; write(KEY.enabled,false); setPhase('BLOQUEADO','Avaliação formal detectada'); return; }
    state.busy=true;
    try{
      state.scans++;
      const pageText=clean(document.body?.innerText||'');
      if(/lesson complete|li[cç][aã]o conclu[ií]da|you finished|voc[eê] concluiu|lesson completed/i.test(pageText) && !nextButton() && !checkButton()) {
        setPhase('LIÇÃO CONCLUÍDA','Lição finalizada; avisando a página principal');
        try{ window.parent?.postMessage({channel:CHANNEL,type:'LESSON_DONE'}, '*'); }catch{}
        state.busy=false; return;
      }
      const task=await (async()=>{const t=getTaskText(); await revealQuestionChoices(t); return getTaskText();})();
      const options=getVisibleOptions();
      const type=activityType(task,options);
      const sig=activitySignature(type,task,options);
      if(!task || !options.length && !/fill|write|speak|order|sort|match|categor/i.test(lower(task))){ state.busy=false; return; }
      state.task=task.slice(0,360); state.activityType=type; state.currentSignature=sig;
      const body=clean(document.body?.innerText||'');
      const stepMatch=body.match(/(?:step|etapa|task)\s*(\d{1,3})\s*(?:of|de|\/)?\s*(\d{1,3})?/i); state.step=stepMatch?stepMatch[2]?`${stepMatch[1]}/${stepMatch[2]}`:stepMatch[1]:'-';
      setPhase('ANALISANDO','Procurando resposta e controle...');
      if(sig===lastSolveSignature && Date.now()-state.lastAttemptAt<2500){state.busy=false;return;}
      lastSolveSignature=sig;
      // special case: page already passed -> advance immediately
      if(resultState()==='passed'){ state.successes++; state.completed++; setPhase('AVANÇANDO','Atividade já concluída; avançando'); await continueOrNext(false); state.busy=false; return; }
      let found=extractAnswerFromData(type,task,options);
      if(!found){
        if(type==='SEQUENCING' && /youngest.*oldest|oldest.*youngest|alphabet/i.test(lower(task))) found={answer:null,source:'REGRA',confidence:90};
      }
      if(found?.answer!=null){
        state.answer=Array.isArray(found.answer)?found.answer.join(' → '):typeof found.answer==='object'?JSON.stringify(found.answer):String(found.answer);
        state.answerSource=found.source; state.confidence=found.confidence;
        saveTelemetry();
        const ok=await applyAnswer(type,task,options,found.answer);
        if(ok){
          await wait(CFG.settleMs);
          const chk=checkButton(); if(chk) safeClick(chk,'CHECK');
          const res=await verifyAfterCheck(sig);
          if(res==='passed'||res==='completed'){
            state.successes++; rememberAnswer(type,task,options,found.answer,found.source,found.confidence); setPhase('AVANÇANDO','Resposta aceita'); await continueOrNext(false);
          }else if(res==='failed'){
            state.failures++; setPhase('RECALCULANDO','Resposta rejeitada; tentando outra resposta');
            if(retryButton()) { safeClick(retryButton(),'RETRY'); await wait(CFG.retryDelay); }
            if(type==='CHOICE' && options.length) {
              const ok2=await tryChoiceTrial(task,options,type);
              if(ok2){ state.successes++; setPhase('AVANÇANDO','Alternativa correta encontrada e verificada'); await continueOrNext(false); }
            }
          }
          state.lastAttemptAt=Date.now(); state.busy=false; return;
        }
      }
      // No explicit answer or application failed: for normal single-choice activities, test options until pass.
      if(type==='CHOICE' && options.length){
        state.answer='tentativa controlada'; state.answerSource='TESTE DAS OPÇÕES'; state.confidence='100% após verificação'; saveTelemetry();
        const ok=await tryChoiceTrial(task,options,type);
        if(ok){state.successes++; setPhase('AVANÇANDO','Alternativa correta encontrada e verificada'); await continueOrNext(false);} else {state.failures++;setPhase('SEM RESPOSTA','Nenhuma alternativa passou');}
      } else {
        setPhase('SEM RESPOSTA','Resposta não encontrada/aplicada para este tipo');
      }
    }catch(e){ state.errors++; setPhase('ERRO',e.message); log(e.stack||e.message,'error'); }
    state.busy=false;
  }

  async function continueOrNext(force=false){
    if(!state.enabled)return false;
    const btn=nextButton();
    if(btn){ safeClick(btn,'NEXT / CONTINUAR'); await wait(1100); return true; }
    if(force){
      const text=lower(document.body?.innerText||'');
      const fallback=qsa('a,button,[role="button"],[tabindex]').filter(visible).find(el=>/(continue|next|proceed|continuar|pr[oó]ximo|avançar|seguir|concluir|finish|done)/i.test(textOf(el)));
      if(fallback){safeClick(fallback,'NEXT FALLBACK');await wait(1000);return true;}
    }
    return false;
  }

  function getLessonCandidates(){
    const out=[];const seen=new Set();
    for(const el of qsa('a,[role="link"],button,[role="button"],h3,h4').filter(visible)){
      const tx=clean(el.innerText||el.textContent||el.getAttribute('aria-label')||'');
      if(!/lição\s*\d|lesson\s*\d/i.test(tx) && !el.getAttribute('aria-label')?.match(/Lição \d de \d/i))continue;
      let card=el.closest('a,[role="link"],button,[role="button"],div[role="button"],div.cursor-pointer,[class*="cursor-pointer"]')||el;
      const label=clean(el.getAttribute('aria-label')||tx);
      const href=card.href||'';
      const key=(href||label); if(seen.has(key))continue;seen.add(key);
      const complete=/status\s+conclu[ií]do|completed|conclu[ií]da/i.test(label); const locked=/bloqueado|locked/i.test(label);
      if(!locked) out.push({el:card,href,label,complete});
    }
    return out;
  }

  function doneSet(){return new Set(read(KEY.done,[])||[]);}
  function saveDone(href){const s=doneSet();s.add(href);write(KEY.done,[...s]);}

  async function findAndOpenNextLesson(){
    if(!IS_MAIN || !state.enabled)return false;
    const candidates=getLessonCandidates();
    if(!candidates.length){ setPhase('AGUARDANDO','Nenhuma lição disponível visível'); return false; }
    const done=doneSet();
    let target=candidates.find(x=>!x.complete && x.href && !done.has(x.href));
    if(!target) target=candidates.find(x=>!x.complete);
    if(!target) { setPhase('CONCLUÍDO','Não há mais lições não concluídas visíveis'); return false; }
    const title=clean(target.label).slice(0,100); state.lesson=title; setPhase('ABRINDO LIÇÃO',title); safeClick(target.el,'ABRIR LIÇÃO'); return true;
  }

  function mainLoop(){
    if(!state.enabled)return;
    if(location.pathname.includes('/lesson-view') && qsa('iframe[src*="lesson-player.study.better.efekta.com"]').length===0){ setPhase('CARREGANDO PLAYER','Aguardando iframe do player...'); return; }
    if(location.pathname.includes('/self-study') && !location.pathname.includes('/lesson-view')) findAndOpenNextLesson();
  }

  function installMainFrameObserver(){
    if(!IS_MAIN)return;
    new MutationObserver(()=>{ if(loopTimer)clearTimeout(loopTimer); loopTimer=setTimeout(mainLoop,400); }).observe(document.documentElement,{subtree:true,childList:true});
  }

  function init(){
    createHub();
    write(KEY.enabled,state.enabled);
    installPageHook();
    if(IS_PLAYER) bridgeNetworkToParent();
    installMainFrameObserver();
    setInterval(()=>{
      if(!state.enabled)return;
      if(IS_PLAYER) processPlayer();
      else mainLoop();
      renderHub();
    }, CFG.scanMs);
    log(`Versão ${VERSION} carregada em ${location.hostname}`,'success');
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true}); else init();

  window.CADUXZ = {state,processPlayer,continueOrNext,findAndOpenNextLesson,extractAnswerFromData,getVisibleOptions,nextButton,checkButton};
})();
